<!DOCTYPE html>
<html>
<head>

	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title> DeliTEN </title> 
	<link rel="icon" type="image/x-icon" href="icon.ico"> 
	<link rel="stylesheet" type="text/css" href="Style.css">
</head>	
<body>
<div class="aside-left">
</div>

<div class="container">
	<nav class="header">
		<div class="logo">
			<h1> DeliTEN. </h1>
		</div>
		<div class="menu">
		
			<ul>
				<li><a href="Homepage.html">Home</a></li>
				<li><a href="About_us.html"> Admin</a></li>
				<li><a href="Homepage.html">Category</a></li>
				<li><a href="Homepage.html">Food</a></li>
				<li><a href="Homepage.html">Order</a></li>
				
			</ul>
		</div>
		
	</nav>
</div>
<div class="main-content">
			<div class="wrapper">
				<h1> DASHBOARD</h1>
				
				<div class="col-4 text-center">
					<h1>5</h1>
					Categories
			</div>
			
			<div class="col-4 text-center">
					<h1>5</h1>
					Categories
			</div>
			
			
			<div class="col-4 text-center">
					<h1>5</h1>
					Categories
			</div>
			
			<div class="col-4 text-center">
					<h1>5</h1>
					Categories
			</div>
			
			<div class="clearfix"></div>
		</div>
		
		
</body>
</head>
</html>
